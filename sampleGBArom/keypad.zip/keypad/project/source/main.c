#include <gba_video.h>
#include <gba_sio.h>
#include <gba_systemcalls.h>
#include <gba_input.h>
#include <gba_interrupt.h>
#include <gba_affine.h>
#include <gba_sprites.h>
#include <gba_dma.h>
#include <gba_console.h>
#include <pcx.h>
#include <fade.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
volatile unsigned short *vram = (unsigned short *)0x06000000;
void SerialInterrupt()
{
	u32 a = REG_SIODATA32;
	vram[a & 0x0000ffff] = a >> 16;
	REG_SIODATA32 = REG_KEYINPUT;
	REG_SIOCNT = SIO_IRQ | SIO_32BIT | SIO_START;
}
int main(void)
{
	SetMode(MODE_3 | BG2_ENABLE);

	irqInit();
	REG_SIOCNT = SIO_IRQ | SIO_32BIT | SIO_START;
	irqSet(IRQ_SERIAL, SerialInterrupt);
	irqEnable(IRQ_VBLANK | IRQ_SERIAL);
	REG_IME = 1;

	//consoleDemoInit();

	//iprintf("\x1b[10;10Haa\n");
	while (1)
	{
		VBlankIntrWait();
	}
	return 0;
}
